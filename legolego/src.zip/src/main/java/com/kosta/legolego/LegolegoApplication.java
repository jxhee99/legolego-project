package com.kosta.legolego;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LegolegoApplication {

	public static void main(String[] args) {
		SpringApplication.run(LegolegoApplication.class, args);
	}

}
